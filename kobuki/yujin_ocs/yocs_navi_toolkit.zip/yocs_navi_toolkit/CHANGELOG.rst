Changelog
=========

0.9.1 (2016-10-19)
------------------
* rotate : try to intelligently rotate out of problems
* honk and wait: moved from yujinrobot's custom navigation fork
